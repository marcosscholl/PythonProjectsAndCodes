# -*- coding: utf-8 -*-
"""
Created on Tue Feb 04 19:21:33 2014

@author: MarcosScholl
"""

from ui_mainwindow import Ui_MainWindow

#Ui_MainWindow.widgetHorizonte.setStyleSheet("background-color: rgba(255, 255, 255, 255);")

Ui_MainWindow.widgetBussola.ui.setupUi().setValue(300)

